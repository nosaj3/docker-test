# dita-relaxng-defaults
DITA Open Toolkit 2.x plugin which allows the DITA OT parser to process default attribute values specified in RelaxNG schemas.
DITA OT 2.x already comes with the Relax NG schemas for the DITA 1.3 vocabulary so you just need to install this plugin (copy the folder "com.oxygenxml.rng.defaults" to the plugins folder and run the integrator) in your DITA OT 2.x and you will be able to publish RNG-based DITA Maps and Topics using the command line "dita.bat" or "dita.sh".
The JAR libraries for this plugin have been either copied from or generated using the GitHub project:
https://github.com/georgebina/dita-ng
